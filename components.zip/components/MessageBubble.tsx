'use client'

import { useState } from 'react'
import ReactMarkdown from 'react-markdown'
import ProductCard from './ProductCard'
import { speakText } from '@/lib/tts'
import type { MadvetProduct } from '@/lib/supabase'

interface MessageBubbleProps {
  messageId: string
  role: 'user' | 'assistant'
  content: string
  products?: MadvetProduct[]
  showFeedback?: boolean
}

export default function MessageBubble({
  messageId,
  role,
  content,
  products = [],
  showFeedback = false,
}: MessageBubbleProps) {
  const isUser = role === 'user'
  const [feedbackSent, setFeedbackSent] = useState<string | null>(null)

  const sendFeedback = async (rating: 'up' | 'down') => {
    if (feedbackSent) return
    try {
      await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messageId,
          rating,
          messageContent: content,
        }),
      })
      setFeedbackSent(rating)
    } catch {
      // ignore
    }
  }

  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      {!isUser && (
        <div className="flex-shrink-0 w-9 h-9 rounded-full bg-madvet-primary flex items-center justify-center text-white font-bold text-sm">
          M
        </div>
      )}
      <div
        className={`max-w-[85%] rounded-2xl px-4 py-3 ${
          isUser
            ? 'bg-madvet-primary text-white'
            : 'bg-white text-gray-800 shadow-md'
        }`}
      >
        {isUser ? (
          <p className="whitespace-pre-wrap">{content}</p>
        ) : (
          <div className="prose prose-sm max-w-none prose-p:my-1 prose-ul:my-1 prose-li:my-0">
            <ReactMarkdown>{content}</ReactMarkdown>
          </div>
        )}
        {!isUser && products.length > 0 && (
          <div className="mt-4 space-y-3">
            {products.map((p, i) => (
              <ProductCard key={i} product={p} />
            ))}
          </div>
        )}
        {!isUser && content && (
          <div className="mt-3 flex items-center gap-2 justify-between">
            <button
              onClick={() => speakText(content)}
              className="p-1.5 rounded-md hover:bg-gray-100 text-gray-500 hover:text-gray-700 transition-colors"
              title="Play audio"
              aria-label="Read aloud"
            >
              🔊
            </button>
            {showFeedback && (
              <>
            <button
              onClick={() => sendFeedback('up')}
              className={`p-1.5 rounded-md transition-colors ${
                feedbackSent === 'up'
                  ? 'bg-madvet-accent text-madvet-primary'
                  : 'hover:bg-gray-100 text-gray-500 hover:text-gray-700'
              }`}
              aria-label="Good"
            >
              👍
            </button>
            <button
              onClick={() => sendFeedback('down')}
              className={`p-1.5 rounded-md transition-colors ${
                feedbackSent === 'down'
                  ? 'bg-red-100 text-red-600'
                  : 'hover:bg-gray-100 text-gray-500 hover:text-gray-700'
              }`}
              aria-label="Bad"
            >
              👎
            </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
