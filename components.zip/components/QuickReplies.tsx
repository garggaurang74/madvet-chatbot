'use client'

const SUGGESTIONS = [
  { id: '1', label: '🐄 Gaay mein keede ka ilaaj', value: 'Gaay mein keede ka ilaaj' },
  { id: '2', label: '🐔 Poultry vitamins', value: 'Poultry vitamins' },
  { id: '3', label: '🩹 Wound treatment', value: 'Wound treatment' },
  { id: '4', label: '💊 Antibiotic for cattle fever', value: 'Antibiotic for cattle fever' },
  { id: '5', label: '🥛 Milk production badhana', value: 'Milk production badhana' },
]

interface QuickRepliesProps {
  onSelect: (value: string) => void
  visible: boolean
}

export default function QuickReplies({ onSelect, visible }: QuickRepliesProps) {
  if (!visible) return null

  return (
    <div className="flex flex-wrap gap-2 px-4 pb-2">
      {SUGGESTIONS.map((s) => (
        <button
          key={s.id}
          onClick={() => onSelect(s.value)}
          className="px-4 py-2 rounded-full text-sm font-medium bg-madvet-accent text-madvet-primary border border-madvet-primary/30 hover:bg-madvet-primary/10 transition-colors"
        >
          {s.label}
        </button>
      ))}
    </div>
  )
}
