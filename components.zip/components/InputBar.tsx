'use client'

import { useRef, useState } from 'react'
import VoiceButton from './VoiceButton'

interface InputBarProps {
  onSend: (text: string) => void
  disabled?: boolean
}

export default function InputBar({ onSend, disabled }: InputBarProps) {
  const [value, setValue] = useState('')
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const handleSubmit = () => {
    const text = value.trim()
    if (!text || disabled) return
    onSend(text)
    setValue('')
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  return (
    <div className="flex items-end gap-2 p-4 bg-white border-t border-gray-200">
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Apni problem Hindi ya English mein likhein..."
        lang="hi"
        rows={1}
        disabled={disabled}
        className="flex-1 resize-none rounded-2xl border border-gray-300 px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-madvet-primary/50 focus:border-madvet-primary disabled:opacity-60"
      />
      <VoiceButton
        onTranscript={(text) => onSend(text)}
        disabled={disabled}
      />
      <button
        onClick={handleSubmit}
        disabled={!value.trim() || disabled}
        className="flex-shrink-0 w-12 h-12 rounded-full bg-madvet-primary text-white flex items-center justify-center hover:bg-madvet-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-opacity"
        aria-label="Send"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="currentColor"
          className="w-5 h-5 rotate-90"
        >
          <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
        </svg>
      </button>
    </div>
  )
}
