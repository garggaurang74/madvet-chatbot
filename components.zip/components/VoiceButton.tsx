'use client'

import { useState, useRef } from 'react'

interface VoiceButtonProps {
  onTranscript: (text: string) => void
  disabled?: boolean
}

export default function VoiceButton({ onTranscript, disabled }: VoiceButtonProps) {
  const [listening, setListening] = useState(false)
  const recognitionRef = useRef<SpeechRecognition | null>(null)

  const startListening = () => {
    const SR =
      (typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition))
    if (!SR) {
      alert('Aapka browser voice input support nahi karta. Chrome use karein.')
      return
    }

    const recognition = new SR()
    recognition.lang = 'hi-IN'
    recognition.interimResults = false
    recognition.maxAlternatives = 1
    recognitionRef.current = recognition

    recognition.onstart = () => setListening(true)
    recognition.onend = () => setListening(false)
    recognition.onerror = () => setListening(false)
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0][0].transcript
      if (transcript) onTranscript(transcript)
    }

    recognition.start()
  }

  const stopListening = () => {
    recognitionRef.current?.stop()
    setListening(false)
  }

  return (
    <button
      onClick={listening ? stopListening : startListening}
      disabled={disabled}
      title={listening ? 'Tap to stop' : 'Tap to speak'}
      className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center transition-all
        ${listening
          ? 'bg-red-500 animate-pulse shadow-lg shadow-red-300'
          : 'bg-madvet-primary hover:bg-madvet-primary/90'
        } disabled:opacity-50 disabled:cursor-not-allowed`}
      aria-label={listening ? 'Stop listening' : 'Start voice input'}
    >
      {listening ? (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
          fill="white" className="w-5 h-5">
          <rect x="6" y="6" width="12" height="12" rx="2"/>
        </svg>
      ) : (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
          fill="white" className="w-5 h-5">
          <path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z"/>
          <path d="M19 10v2a7 7 0 01-14 0v-2M12 19v4M8 23h8"/>
        </svg>
      )}
    </button>
  )
}
