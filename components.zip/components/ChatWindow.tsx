'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import MessageBubble from './MessageBubble'
import InputBar from './InputBar'
import TypingIndicator from './TypingIndicator'
import QuickReplies from './QuickReplies'
import { extractMentionedProducts } from '@/lib/extractProducts'
import { speakText, stopSpeaking } from '@/lib/tts'
import type { MadvetProduct } from '@/lib/supabase'

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  products?: MadvetProduct[]
}

async function fetchProducts(): Promise<MadvetProduct[]> {
  const res = await fetch('/api/products')
  if (!res.ok) return []
  const data = await res.json()
  return data.products ?? []
}

export default function ChatWindow() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [products, setProducts] = useState<MadvetProduct[]>([])
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [showQuickReplies, setShowQuickReplies] = useState(true)
  const [voiceEnabled, setVoiceEnabled] = useState(true)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    fetchProducts()
      .then(setProducts)
      .catch(() => setProducts([]))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: 'smooth',
    })
  }, [messages, sending])

  const sendMessage = useCallback(
    async (text: string) => {
      if (!text.trim() || sending) return

      stopSpeaking()
      setShowQuickReplies(false)

      const userMsg: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'user',
        content: text.trim(),
      }
      setMessages((prev) => [...prev, userMsg])
      setSending(true)

      const history = [...messages, userMsg].map((m) => ({
        role: m.role,
        content: m.content,
      }))

      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: history,
            latestMessage: text.trim(),
          }),
        })

        if (!res.ok) {
          const err = await res.json().catch(() => ({}))
          const msg = err.debug ? `${err.error} (${err.debug})` : (err.error || 'Request failed')
          throw new Error(msg)
        }

        const reader = res.body?.getReader()
        const decoder = new TextDecoder()
        let full = ''

        const assistantId = crypto.randomUUID()
        setMessages((prev) => [
          ...prev,
          {
            id: assistantId,
            role: 'assistant',
            content: '',
            products: [],
          },
        ])

        if (reader) {
          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            const chunk = decoder.decode(value, { stream: true })
            full += chunk
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantId
                  ? {
                      ...m,
                      content: full,
                      products: extractMentionedProducts(full, products),
                    }
                  : m
              )
            )
          }
          if (voiceEnabled && full) {
            speakText(full)
          }
        }
      } catch (err) {
        const errMsg =
          err instanceof Error ? err.message : 'Thoda technical issue aa gaya, please dobara try karein 🙏'
        setMessages((prev) => [
          ...prev,
          {
            id: crypto.randomUUID(),
            role: 'assistant',
            content: errMsg,
          },
        ])
      } finally {
        setSending(false)
        fetchProducts().then((p) => {
          setProducts(p)
        })
      }
    },
    [messages, sending, products, voiceEnabled]
  )

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#f8fafb]">
        <div className="w-10 h-10 border-4 border-madvet-primary border-t-transparent rounded-full animate-spin" />
        <p className="mt-4 text-gray-600">Madvet products load ho rahe hain...</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-screen bg-[#f8fafb] relative">
      <button
        onClick={() => setVoiceEnabled((v) => !v)}
        title={voiceEnabled ? 'Voice on (click to mute)' : 'Voice off (click to unmute)'}
        className="fixed top-4 right-4 z-50 w-10 h-10 rounded-full flex items-center justify-center shadow-md transition-colors bg-white border border-gray-200 hover:bg-gray-50"
        aria-label={voiceEnabled ? 'Mute voice' : 'Unmute voice'}
      >
        {voiceEnabled ? '🔊' : '🔇'}
      </button>
      <header className="flex-shrink-0 flex items-center gap-3 px-4 py-3 bg-white border-b border-gray-200 shadow-sm">
        <div className="w-10 h-10 rounded-full bg-madvet-primary flex items-center justify-center text-white font-bold">
          M
        </div>
        <div>
          <h1 className="text-lg font-bold text-madvet-primary">Madvet</h1>
          <p className="text-xs text-gray-500">Dr. Madvet Assistant</p>
        </div>
        <div className="ml-auto flex items-center gap-2 text-sm text-green-600">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          Online
        </div>
      </header>

      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-4 py-6 space-y-6"
      >
        {messages.map((m) => (
          <MessageBubble
            key={m.id}
            messageId={m.id}
            role={m.role}
            content={m.content}
            products={m.products}
            showFeedback={
              m.role === 'assistant' &&
              !!m.content &&
              !(messages.indexOf(m) === messages.length - 1 && sending)
            }
          />
        ))}
        {sending && messages[messages.length - 1]?.role === 'user' && (
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-9 h-9 rounded-full bg-madvet-primary flex items-center justify-center text-white font-bold text-sm">
              M
            </div>
            <div className="bg-white rounded-2xl px-4 py-3 shadow-md">
              <TypingIndicator />
            </div>
          </div>
        )}
      </div>

      <div className="flex-shrink-0 bg-white">
        <QuickReplies onSelect={sendMessage} visible={showQuickReplies} />
        <InputBar onSend={sendMessage} disabled={sending} />
      </div>
    </div>
  )
}
