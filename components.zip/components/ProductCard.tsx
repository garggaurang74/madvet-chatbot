'use client'

import type { MadvetProduct } from '@/lib/supabase'

interface ProductCardProps {
  product: MadvetProduct
}

export default function ProductCard({ product }: ProductCardProps) {
  const name = product.product_name || 'Unknown Product'
  const salt = product.salt
  const dosage = product.dosage
  const packing = product.packing
  const hasAntibioticOrAntiparasitic =
    (salt?.toLowerCase().includes('antibiotic') ||
      salt?.toLowerCase().includes('ivermectin') ||
      salt?.toLowerCase().includes('antiparasitic') ||
      name.toLowerCase().includes('antibiotic')) ??
    false

  return (
    <div className="rounded-xl border-2 border-madvet-accent bg-white p-4 shadow-sm">
      <p className="font-semibold text-madvet-primary">{name}</p>
      {salt && (
        <p className="mt-1 text-sm text-gray-600">
          <span className="font-medium">Composition:</span> {salt}
        </p>
      )}
      {dosage && (
        <p className="mt-1 text-sm text-gray-700">
          <span className="font-medium">💊 Dosage:</span> {dosage}
        </p>
      )}
      {packing && (
        <p className="mt-1 text-sm text-gray-600">
          <span className="font-medium">📦 Packing:</span> {packing}
        </p>
      )}
      {hasAntibioticOrAntiparasitic && (
        <p className="mt-2 text-sm text-red-600 font-medium">
          ⚠️ Withdrawal period (milk/meat) check karein — product leaflet dekhein
        </p>
      )}
    </div>
  )
}
