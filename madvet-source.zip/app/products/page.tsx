import { Metadata } from 'next'
import { createClient } from '@supabase/supabase-js'
import { Suspense } from 'react'
import ProductsClient from './ProductsClient'
import type { Product } from './types'

export type { Product }

export const metadata: Metadata = {
  title: 'Products | Madvet Animal Healthcare',
  description: 'Complete range of Madvet veterinary products — antibiotics, supplements, dewormers and more.',
}

// Always fetch fresh from Supabase — admin image updates must reflect immediately.
export const dynamic = 'force-dynamic'
export const fetchCache = 'force-no-store'

const CAT_NORMALIZE: Record<string, string> = {
  'Anti-inflammatory':                               'Anti-inflammatory / Analgesic',
  'Anti-inflammatory, Analgesic, Antipyretic':       'Anti-inflammatory / Analgesic',
  'Anti-inflammatory / Analgesic / Antipyretic':     'Anti-inflammatory / Analgesic',
  'Analgesic / Antipyretic':                         'Anti-inflammatory / Analgesic',
  'Analgesic, Antipyretic':                          'Anti-inflammatory / Analgesic',
  'Analgesic':                                       'Anti-inflammatory / Analgesic',
  'Anthelmintic':                                    'Anthelmintic / Antiparasitic',
  'Antiparasitic':                                   'Anthelmintic / Antiparasitic',
  'Antibiotic (Cephalosporin)':                      'Antibiotic',
  'Antibiotic (Fluoroquinolone)':                    'Antibiotic',
  'Antihistamine / Anti-allergic':                   'Antihistamine',
  'Dermatological / Topical':                        'Dermatological',
  'Probiotic / Immunomodulator / Vitamin Supplement':'Probiotic',
  'Antidiarrheal / Gastrointestinal':                'Antidiarrheal',
}

function normalizeCategory(c: string): string {
  return CAT_NORMALIZE[c] || c
}

function getFormulationFallback(packaging: string): string {
  const p = packaging.toLowerCase()
  if (p.includes('bolus'))                                                  return 'Bolus'
  if (p.includes('inj') || p.includes('syringe'))                          return 'Injection'
  if (p.includes('tablet') || p.includes(' tab'))                          return 'Tablet'
  if (p.includes('spray'))                                                  return 'Spray'
  if (p.includes('gel') || p.includes('ointment') || p.includes('cream'))  return 'Gel / Ointment'
  if (p.includes('soap'))                                                   return 'Soap'
  if (p.includes('powder') || p.includes('sachet') || p.includes(' gm') || p.includes(' kg')) return 'Powder'
  if (p.includes('pour-on') || p.includes('pour on'))                      return 'Pour-On'
  if (p.includes('suspension'))                                             return 'Suspension'
  if (p.includes('syrup') || p.includes('liq') || p.includes('liquid') ||
      p.includes('solution') || p.includes(' ml') || p.includes(' litre') ||
      p.includes(' liter'))                                                 return 'Liquid'
  return 'Other'
}

async function fetchProducts(): Promise<Product[]> {
  const url   = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key   = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  const table = process.env.NEXT_PUBLIC_SUPABASE_TABLE || 'products_enriched'

  if (!url || !key) return []

  const supabase = createClient(url, key)

  const { data, error } = await supabase
    .from(table)
    .select('id, product_name, salt_ingredient, packaging, formulation, category, species, indication, description, usp_benefits, description_hi, usp_benefits_hi, aliases, image_url, video_url')
    .order('id', { ascending: true })
    .limit(500)

  if (error || !data) {
    console.error('[Products] Supabase error:', error?.message)
    return []
  }

  return data.map((row: any): Product => {
    const rawPackaging = (row.packaging || '').trim()
    const formulation  = (row.formulation || '').trim() || getFormulationFallback(rawPackaging)

    return {
      id:          Number(row.id),
      name:        (row.product_name    || '').trim(),
      salt:        (row.salt_ingredient || '').trim(),
      packaging:   rawPackaging,
      formulation,
      category:    normalizeCategory((row.category || '').trim()),
      species:     (row.species         || '').trim(),
      indication:  (row.indication      || '').trim(),
      description: (row.description     || '').trim(),
      benefits:    (row.usp_benefits    || '').trim(),
      description_hi:  (row.description_hi  || '').trim(),
      usp_benefits_hi: (row.usp_benefits_hi || '').trim(),
      aliases:     (row.aliases         || '').trim(),
      image_url:   (row.image_url       || '').trim(),
      video_url:   (row.video_url        || '').trim(),
    }
  })
}

// ProductsFetcher is the async server component that does the Supabase call.
// Wrapping it in Suspense means Next.js streams the outer shell (nav, header)
// to the browser immediately, and slots in the product grid once ready.
async function ProductsFetcher() {
  const products = await fetchProducts()
  return <ProductsClient products={products} />
}

function ProductsSkeleton() {
  return (
    <div style={{
      maxWidth: 1400, margin: '48px auto', padding: '0 48px',
      display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 20,
    }}>
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} style={{
          background: '#ede6d6', borderRadius: 14, height: 260,
          animation: 'pulse 1.5s ease-in-out infinite',
          opacity: 0.5 + (i % 3) * 0.1,
        }} />
      ))}
      <style>{`@keyframes pulse { 0%,100%{opacity:.4} 50%{opacity:.7} }`}</style>
    </div>
  )
}

export default function ProductsPage() {
  return (
    <Suspense fallback={<ProductsSkeleton />}>
      <ProductsFetcher />
    </Suspense>
  )
}
